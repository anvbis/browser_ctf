# Outfoxed
## Building
The base changeset of the Firefox build is `655554:f4922b9e9a6b`, with a short (log)[./log] provided.
The (mozconfig file)[./mozconfig] used to build the challenge is also provided.

## Environment
The challenge is run with the content sandbox disabled:
`MOZ_DISABLE_CONTENT_SANDBOX ./firefox`

